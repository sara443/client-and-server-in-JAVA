package Client.Controllers;

//import Client.Models.User;
import java.io.BufferedReader;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.control.Alert;

public class LoginController {
    @FXML
    public TextField emailField;
    @FXML
    public PasswordField passwordField;
    
    @FXML
    public TextField nameField;


    @FXML
    public void Login(ActionEvent actionEvent) {
        try {
            Socket socket = new Socket ("localhost" , 5001);
            BufferedReader in = new BufferedReader (new InputStreamReader(socket.getInputStream()));
            PrintWriter out = new PrintWriter(socket.getOutputStream(),true);
             out.println("w");
            String email = emailField.getText();
            String password = passwordField.getText();
            out.println(email);
            out.println(password);
            String check = in.readLine();

            if(check.equals("Success"))
            {
//           Alert alert = new Alert(Alert.AlertType.INFORMATION);
//            alert.setTitle("Login Success");
//            alert.setHeaderText("Login Successful!");
//            alert.setContentText("Correct email and password.");
//            alert.showAndWait();
                try {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/Client/Scenes/Application.fxml"));
                    Parent root = loader.load();
                    Scene scene = new Scene(root);
                    Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
                    stage.setScene(scene);
                    stage.show();
                } catch (IOException e) {
                    Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, e);
                }
            }
            else{
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Login Failed");
            alert.setHeaderText("Login Failed!");
            alert.setContentText("Wrong username or password.");
            alert.showAndWait();
            }
            
           
        } catch (IOException ex) {
            Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
        }
            
            
            

    }
    
   
    
    
    
    

    @FXML
    public void SwitchToSignupScene(ActionEvent actionEvent) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Client/Scenes/SignupScene.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, e);
        }
    }
}
