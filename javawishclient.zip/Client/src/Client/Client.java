package Client;

import Client.Controllers.LoginController;
//import Client.Controllers.SocketController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Client extends Application {
//    private final SocketController socketController;

// s

    public static void main(String[] args) {
        launch(args);
    }

    public void start(Stage primaryStage) throws Exception {
        // Testing Connection
        //this.socketController.connect();
        //this.socketController.disconnect();

        // Loading Scene
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Client/Scenes/LoginScene.fxml"));
        Parent root = loader.load();

        LoginController loginController = loader.getController();
//        loginController.setSocketController(this.socketController);

        Scene scene = new Scene(root);
        scene.setRoot(root);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
