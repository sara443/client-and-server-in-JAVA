/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import org.apache.derby.jdbc.ClientDriver;

/**
 *
 * @author Sara
 */
public class Server2 {

    ServerSocket server;
    Connection con;
    public Server2()
    {
        
        
        try {
            DriverManager.registerDriver(new ClientDriver());
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/phonebook","sara","123");
            server = new ServerSocket(5001);
            Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE) ;
            String data = new String("select * from IWISH");
            ResultSet rs ;
            rs = (ResultSet) stmt.executeQuery(data) ;
        } catch (SQLException ex) {
            Logger.getLogger(Server2.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Server2.class.getName()).log(Level.SEVERE, null, ex);
        }
        
 
  
     

    
    while(true){
            try {
                Socket socket = server.accept();
                Thread th = new Thread(new Handler(socket));
                th.start();
            } catch (IOException ex) {
                Logger.getLogger(Server2.class.getName()).log(Level.SEVERE, null, ex);
            }
    }
       
    }
    public class Handler extends Thread {
        Socket mysocket; 
        public Handler (Socket s){
        mysocket=s;
        }
        public void run() {
            ResultSet rs = null;
            PreparedStatement stmt;
        try (BufferedReader in = new BufferedReader(new InputStreamReader(mysocket.getInputStream()));
         PrintWriter out = new PrintWriter(mysocket.getOutputStream(), true)) {
         String flag = in.readLine();
         if (flag.equals("w"))
         {
            String check = "select * from IWISH WHERE EMAIL = ? AND PASSWORD = ?";
            String email = in.readLine();
            String pass = in.readLine();
            Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/phonebook","sara","123");
            PreparedStatement stmt1 = con.prepareStatement(check, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            stmt1.setString(1, email);
            stmt1.setString(2, pass);
            rs = stmt1.executeQuery();
         if (rs.next()) {

                    out.println("Success");
                }else {
                    out.println("Fail");
                } 
             
         }
         
         else if (flag.equals("s"))
         {
           String emailup = in.readLine();
        String passup = in.readLine();
        String name = in.readLine();
       String check = "select * from IWISH WHERE EMAIL = ? ";
       stmt = con.prepareStatement(check, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
       stmt.setString(1, emailup);
       
       rs = stmt.executeQuery();
//        System.out.println(rs.toString());
        if (rs.next()) {
            out.println("Fail");
        }else {
//            String update = "update IWISH set NAME = ?, EMAIL = ?, PASSWORD = ?";

            String update = " insert into IWISH (name,email,password) values  (?,?,?)";
            Connection conn = DriverManager.getConnection("jdbc:derby://localhost:1527/phonebook","sara","123");
            PreparedStatement stmt2 = conn.prepareStatement(update, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            stmt2.setString(1, name);
            
            stmt2.setString(2, emailup );
            stmt2.setString(3, passup);
            stmt2.executeUpdate();
            out.println("Success");
        }
  
         }
             
             
            
            

        
    } catch (SQLException | IOException ex) {
        Logger.getLogger(Server2.class.getName()).log(Level.SEVERE, null, ex);
    }
//    } finally {
//        try {
//            mysocket.close();
//        } catch (IOException ex) {
//            Logger.getLogger(Server2.class.getName()).log(Level.SEVERE, null, ex);
//        }
//    }
}
        
    }
    
    public static void main(String[] args) {
        new Server2();
    }
    
}
